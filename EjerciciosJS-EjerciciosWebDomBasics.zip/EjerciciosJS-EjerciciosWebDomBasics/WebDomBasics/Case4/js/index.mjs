import { toggleShowCompletedHandler } from "./controllers/main.mjs"
document.querySelector("#theinput").addEventListener("click",toggleShowCompletedHandler)