import { multiplyByTwo } from "./controllers/main.mjs"
document.querySelector("#thebutton").addEventListener("click",multiplyByTwo)