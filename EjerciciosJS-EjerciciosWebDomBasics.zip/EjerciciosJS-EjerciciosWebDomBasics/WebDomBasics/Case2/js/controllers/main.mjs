export function multiplyByTwo (event) {
    event.preventDefault()
    console.log("prueba");
    const inputvalue = document.getElementById("theinput").value;
    console.log(inputvalue);
    const multiplicacion = inputvalue * 2;
    const p = document.createElement('p');
    p.innerText = multiplicacion;
    document.querySelector("#multi").append(p);
}
