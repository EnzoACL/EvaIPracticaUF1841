// La siguiente función es empleada por el método sort de un array.
// Informate sobre los requisitos que ha de cumplir la función.
//La funcion compareRunners con el metodo sort compara los elementos y 
//devuelve si es negativo un cambio de orden.
export function compareRunners (a, b) {
    return a.time - b.time
}