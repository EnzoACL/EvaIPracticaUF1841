import {compareRunners} from "../auxiliar/comparators.mjs"
//Se usa funcion que ordena para construir el elemento html con los datos ordendos
export function dataToHTMLList (array) {
    array.sort(compareRunners)
    const HTMLElements = array.map(
        (item) => {
            const li = document.createElement("li");
            li.innerText = `Nombre: ${item.name} - Tiempo: ${item.time}.`;
            return li;
        }
    )
    document.querySelector("#list").append(...HTMLElements);
}