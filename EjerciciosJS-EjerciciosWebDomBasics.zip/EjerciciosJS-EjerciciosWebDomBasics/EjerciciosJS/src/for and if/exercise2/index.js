const numbers = [0,1,2,4,5,9,3,6,7,8];
let counter=0
for (let item of numbers) {
    counter++
}

console.log(counter)