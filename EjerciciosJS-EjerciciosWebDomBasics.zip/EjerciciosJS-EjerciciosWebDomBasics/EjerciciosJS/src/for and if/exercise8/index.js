// Put your code here


//for (let outer=0; outer < 51 ; outer+=five) {
  //  console.log(`5*${counter5}: ${outer}`);
  //  counter5++
//}



//for (let inner=0;inner<61;inner+=6) {
//    console.log(`6*${counter6}: ${inner}`);
  //  counter6++
//}             

for (let numeros=1;numeros<11;numeros++){
    let contadortotal=1
    for (let multi=1; multi<11;multi++){
        let res = numeros*multi
       console.log(`${numeros} * ${contadortotal++} = ${res}`);
    }
}