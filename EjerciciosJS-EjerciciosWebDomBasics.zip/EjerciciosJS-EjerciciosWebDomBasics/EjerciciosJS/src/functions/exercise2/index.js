let number0 = 0;

function plusone(sumeFuction) {
    let sum = number0 + 1;
    return sum;
}

plusone(number0);

console.log(plusone(number0))