# As a team

Crea en [index.js](index.js) las siguientes funciones:

* `aGreatherThanB(a, b)`
    * Entrega `true` si `a` es mayor que `b`. En otro caso entrega `false`.
* `bGreatherThanA(a,b)`
    * Entrega `true` si `b` es mayor que `a`. En otro caso entrega `false`.
* `swap(idxA, idxB, array)`
    * Cambia las posiciones del elemento en las posiciones `idxA` e `idxB` del array `array`. Esta ya deberías de tenerlas hechas.
