# Functions

* Revisa y comprende el contenido de [example.js](example.js).
* Aplicando los conceptos expuestos en example.js, completa el código de [index.js](index.js) definiendo una función que busque y entregue (return) el menor valor de un array de números, insertando el código necesario en el lugar indicado por el comentario.
