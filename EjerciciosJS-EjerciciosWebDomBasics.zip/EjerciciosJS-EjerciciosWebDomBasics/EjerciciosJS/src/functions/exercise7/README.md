# By myself

¿Puede una función hacer referencia a si misma?. Pues sí. Se llama recursividad.

Tienes un ejemplo en el fichero [example.js](example.js).

Fíjate en la función ```sort``` en ese fichero. Intenta analizar, con lápiz y papel, cómo funciona. ¿Qué información recibe la función cada vez que se ejecuta?.