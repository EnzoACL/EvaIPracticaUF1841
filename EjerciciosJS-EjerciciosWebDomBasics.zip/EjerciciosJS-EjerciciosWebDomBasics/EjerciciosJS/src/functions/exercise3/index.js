function power (numero,elevadoa = 1/2){
    return numero**elevadoa
}
// Put your code here

console.log(power(25))
console.log(power(8,1/3))
console.log(power(2,3))
console.log(power(5,2))